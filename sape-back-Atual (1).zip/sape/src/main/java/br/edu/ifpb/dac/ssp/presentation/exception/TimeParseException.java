package br.edu.ifpb.dac.ssp.presentation.exception;

public class TimeParseException extends Exception {

	private static final long serialVersionUID = 1L;
	
	public TimeParseException(String message) {
		super(message);
	}
}
