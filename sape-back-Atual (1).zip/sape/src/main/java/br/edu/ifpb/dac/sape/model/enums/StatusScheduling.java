package br.edu.ifpb.dac.sape.model.enums;

public enum StatusScheduling {
	
	PENDENTE,  CONFIRMADO, CANCELADO;

}
