package br.edu.ifpb.dac.ssp.presentation.exception;

public class ObjectAlreadyExistsException extends Exception {

	public ObjectAlreadyExistsException(String message) {
		super(message);
	}
}
