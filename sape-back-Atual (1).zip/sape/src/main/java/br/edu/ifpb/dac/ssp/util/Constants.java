package br.edu.ifpb.dac.ssp.util;

public class Constants {
	
	public static final long MAXIMUM_DURATION_PRACTICE_MINUTES = 180;
	public static final String INSTITUTION_OPENING_TIME = "07:00";
	public static final String INSTITUTION_CLOSING_TIME = "22:00";

}
