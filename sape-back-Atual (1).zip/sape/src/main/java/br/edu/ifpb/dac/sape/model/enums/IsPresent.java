package br.edu.ifpb.dac.sape.model.enums;

public enum IsPresent {
	YES , NO

}
